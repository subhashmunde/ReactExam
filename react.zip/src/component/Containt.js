import React from 'react'
import Category from './Category'


export default function Containt() {
  return (
    <div className='container'>
            <Category/>
    </div>
  )
}
